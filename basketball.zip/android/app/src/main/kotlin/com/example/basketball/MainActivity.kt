package com.example.basketball

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
